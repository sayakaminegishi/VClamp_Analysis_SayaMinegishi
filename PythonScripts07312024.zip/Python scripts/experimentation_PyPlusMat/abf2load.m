function [d,si,h]=abf2load(fn,varargin)
% Delegates to abfload.
[d,si,h]=abfload(fn,varargin{:});

